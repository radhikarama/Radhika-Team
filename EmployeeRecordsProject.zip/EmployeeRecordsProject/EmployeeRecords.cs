﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeRecords
    {
        public int EmpId;
        public string EmpName;
        public long PhoneNo;
        public int DeptId;
        public int ManagerId;

        public EmployeeRecords()
        {
            Console.WriteLine("Enter the Employee Id");
            EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Employee Name");
            EmpName = Console.ReadLine();
            Console.WriteLine("Enter the Employee Phone Number");
            PhoneNo = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Employee Department Id");
            DeptId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Manager Id");
            ManagerId =int.Parse(Console.ReadLine());
        }
          public override string ToString()
        {
            return EmpId.ToString().PadLeft(20) + "|" + EmpName.PadLeft(20) + "|" +
              PhoneNo.ToString().PadLeft(20) + "|" + DeptId.ToString().PadLeft(20) + "|" + ManagerId.ToString().PadLeft(20) + "\n";
        }

       
    }
}
