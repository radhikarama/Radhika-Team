﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeDetailsTest
    {
        public static string filename = @"C:\Users\DELL\Desktop\EmployeeRecords.txt";
        public static string departfile = @"C:\Users\DELL\Desktop\DepartmentRecords.txt";
       public static string projectsfile = @"C:\Users\DELL\Desktop\ProjectsRecords.txt";

        public void RetrivingNoOfProjects()
        {
            int flag = -1;
            Console.WriteLine("Enter the Department name");
            string name = Console.ReadLine();
            try
            {
                string line, id = "";
                using (StreamReader reader = new StreamReader(departfile))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(name))
                        {
                            flag = 1;
                           var proj=line.Split('|').Last();
                            Console.WriteLine("Number of Projects:"+proj);
                        }                    
                    }
                    if (flag == -1)
                        Console.WriteLine(" \t\t\t PROJECT NAME DOES NOT EXIST IN THE FILE");
                }
            }catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void BasedOnDepartment()
        {
            int flag = -1;
            Console.WriteLine("Enter the Department name");
            string name = Console.ReadLine();
            try
            {
                string line, id = "", line1;
               
                    using (StreamReader reader = new StreamReader(departfile))
                {
                    using (StreamReader reader1 = new StreamReader(filename))
                    {
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Contains(name))
                            { 
                                id = line.Split('|').First();
                                flag = 1;
                            }
                            
                        }
                        if (flag == -1)
                            Console.WriteLine(" \t\t\t DEPARMENT NAME DOES NOT EXIST IN THE FILE");
                        else { 
     Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(22) + "MANAGER ID".PadLeft(22));
                            while ((line1 = reader1.ReadLine()) != null)
                            {
                                if (line1.Contains(id))
                                {
                                    Console.WriteLine(line1);
                                    Console.WriteLine();

                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void BasedOnProject()
        {
            int flag = -1;
            Console.WriteLine("Enter the Manager Id");
            string manager = Console.ReadLine();           
            try
            {
                string line1, line;
                using (StreamReader reader = new StreamReader(projectsfile))
                {
                    using (StreamReader reader1 = new StreamReader(filename))
                    {
                        Console.WriteLine("PROJECT ID".PadLeft(20) + "PROJECT NAME".PadLeft(20) + "MANAGER ID".PadLeft(22));
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Contains(manager))
                            {
                                flag = 1;
                                Console.WriteLine(line);
                            }
                        }
                        Console.WriteLine("----------------------");
                                if (flag == -1)
                            Console.WriteLine(" \t\t\t MANAGER ID DOES NOT EXIST IN THE FILE");
                        else
                        {
     Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(20) + "MANAGER ID".PadLeft(22));
                            while ((line1 = reader1.ReadLine()) != null)
                                {
                                if (line1.Contains(manager))
                                    {
                                    Console.WriteLine(line1);
                                    Console.WriteLine();
                                     }
                                 }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        static void Main(string[] args)
        {
            EmployeeDetailsTest employee = new EmployeeDetailsTest();
            int ch,flag = -1; 
          
            do
            {              
                Console.WriteLine(" 1) Inserting Employee Details into File");             
                Console.WriteLine(" 2) Inserting Department Details into File");              
                Console.WriteLine(" 3) Inserting Project Details into File");
                Console.WriteLine(" 4) Search all Employees who is under particular Department Name");
                Console.WriteLine(" 5) Search all Employees who is under particular Manager Id");
                Console.WriteLine(" 6) Searching Number of Projects using Project name");
                Console.WriteLine(" 7) Exit ");
                Console.WriteLine("\t\t\t\t =====> EMPLOYEE MANAGEMENT PROJECT <=====");
                Console.WriteLine("ENTER THE CHOICE");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {                  
                    case 1:
                        EmployeeRecords emp1 = new EmployeeRecords();
                        string line;
                        try
                        {                          
                            using (StreamReader reader = new StreamReader(filename))
                            {
                               
                                while ((line = reader.ReadLine()) != null)
                                {                                 
                                    var empid = emp1.EmpId.ToString();
                                    if (line.Contains(empid))
                                    {
                                        flag = 0;
                                      break;
                                    }
                                    else
                                        flag = -1;                         
                                }
                            }
                            if(flag==0)
                                Console.WriteLine("EMPLOYEE ID IS ALREADY EXISTS");

                            if (flag == -1)
                            {                               
                                    using (StreamWriter writer = new StreamWriter(filename, true))
                                    {
                                        writer.Write(emp1);
                                    }                                
                            }
                            
                           
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                  
                    case 2:
                        DepartmentDetails dept = new DepartmentDetails();
                        try
                        {

                            using (StreamReader reader = new StreamReader(departfile))
                            {

                                while ((line = reader.ReadLine()) != null)
                                {
                                    var deptid = dept.DeptId.ToString();
                                    if (line.Contains(deptid))
                                    {
                                        flag = 0;
                                        break;
                                    }
                                    else
                                        flag = -1;
                                }
                            }
                            if (flag == 0)
                                Console.WriteLine("DEPARTMENT ID IS ALREADY EXISTS");

                            if (flag == -1)
                            {
                                using (StreamWriter writer = new StreamWriter(departfile, true))
                                {
                                    writer.Write(dept);
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                  
                    case 3:
                        ProjectDetails projects1= new ProjectDetails();
                        try
                        {
                            using (StreamReader reader = new StreamReader(projectsfile))
                            {
                                while ((line = reader.ReadLine()) != null)
                                {
                                    var projectid = projects1.ProjId.ToString();
                                    if (line.Contains(projectid))
                                    {
                                        flag = 0;
                                        break;
                                    }
                                    else
                                        flag = -1;
                                }
                            }
                            if (flag == 0)
                                Console.WriteLine("PROJECT ID IS ALREADY EXISTS");

                            if (flag == -1)
                            {
                                using (StreamWriter writer = new StreamWriter(projectsfile,true))
                                {
                                    writer.Write(projects1);
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:
                        employee.BasedOnDepartment();
                        break;
                    case 5:
                        employee.BasedOnProject();
                                break;
                    case 6:
                        employee.RetrivingNoOfProjects();
                                            break;
                    case 7: Environment.Exit(1);
                        break;
                    default: Console.WriteLine("Invalid Choice");break;
                }
            } while (ch !=7);
            Console.ReadLine();
        }
    }
}
