﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeDetailsTest
    {
        public static string filename = @"C:\Users\DELL\Desktop\EmployeeRecords.txt";
        public static string departfile = @"C:\Users\DELL\Desktop\DepartmentRecords.txt";
       public static string projectsfile = @"C:\Users\DELL\Desktop\ProjectsRecords.txt";

        public void RetrivingNoOfProjects()
        {
            Console.WriteLine("Enter the Department name");
            string name = Console.ReadLine();
            try
            {
                string line, id = "";
                using (StreamReader reader = new StreamReader(departfile))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(name))
                        {
                           var proj=line.Split(' ').Last();
                            Console.WriteLine("Number of Projects:"+"\t"+proj);
                        }                    
                    }
                }
            }catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void BasedOnDepartment()
        {
            Console.WriteLine("Enter the Department name");
            string name = Console.ReadLine();
            try
            {
               Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(20) + "MANAGER ID".PadLeft(22));

                string line, id = "", line1;
                using (StreamReader reader = new StreamReader(departfile))
                {
                    using (StreamReader reader1 = new StreamReader(filename))
                    {
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Contains(name))
                            { 
                                id = line.Split('|').First();
                            }
                        }
                        while ((line1 = reader1.ReadLine()) != null)
                        {
                            if (line1.Contains(id))
                            {
                                Console.WriteLine(line1);
                                Console.WriteLine();
                               
                            }
                        }
                    }
                }

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void BasedOnProject()
        {
            Console.WriteLine("Enter the Manager Id");
            string manager = Console.ReadLine();
            Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(20) + "MANAGER ID".PadLeft(22));
            try
            {
                string line1;                         
                    using (StreamReader reader1 = new StreamReader(filename))
                    {                     
                        while ((line1 = reader1.ReadLine())!= null)
                        {
                            if (line1.Contains(manager))
                            {
                          Console.WriteLine(line1);
                            Console.WriteLine();
                        }
                        }
                         }                                          
                    }               
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        static void Main(string[] args)
        {
            EmployeeDetailsTest employee = new EmployeeDetailsTest();
            int ch;
          
            do
            {
               
                Console.WriteLine(" 1) Inserting Employee Details into File");             
                Console.WriteLine(" 2) Inserting Department Details into File");              
                Console.WriteLine(" 3) Inserting Project Details into File");
                Console.WriteLine(" 4) Search all Employees who is under particular Department ");
                Console.WriteLine(" 5) Search all Projects by Employee Id ");
                Console.WriteLine(" 6) Searching Number of Projects");
                Console.WriteLine(" 7) Exit ");
                Console.WriteLine("ENTER THE CHOICE");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                   
                    case 1:
                        EmployeeRecords emp1 = new EmployeeRecords();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename, true))
                            {
                              
                                    writer.Write(emp1);
                               
                            }
                           
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                  
                    case 2:
                        DepartmentDetails dept = new DepartmentDetails();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(departfile, true))
                            {
                               writer.Write(dept);
                                  }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                  
                    case 3:
                        ProjectDetails projects1= new ProjectDetails();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(projectsfile,true))
                            {
                                 writer.Write(projects1);                           
                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:
                        employee.BasedOnDepartment();
                        break;
                    case 5:
                        employee.BasedOnProject();
                                break;
                    case 6:
                        employee.RetrivingNoOfProjects();
                                            break;
                    case 7: Environment.Exit(1);
                        break;
                    default: Console.WriteLine("Invalid Choice");break;
                }
            } while (ch !=7);
            Console.ReadLine();
        }
    }
}
